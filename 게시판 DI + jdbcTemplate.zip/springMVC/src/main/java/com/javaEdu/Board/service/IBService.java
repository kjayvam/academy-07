package com.javaEdu.Board.service;

import org.springframework.ui.Model;

public interface IBService {

	public void execute(Model model);
}


